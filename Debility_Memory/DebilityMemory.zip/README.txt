Debility Memory - toDo list
---------------------------

Zobrazenie: 

vsetky splnene polozky - zelene podfarbenie
nesplnene polozky po deadline - cervene podfarbenie
nesplnene polozky pred deadlinom - bez podfarbenia
vsetky polozky pred deadlinom (aktivne) - bold text


Ovladanie:

pridat novu polozku - text area New item, vybrat deadline kliknutim na tlacidlo 		deadline, potvrdit vyber stlacenim OK, pridat polozku kliknutim na 		tlacidlo plus

oznacit polozku ako splnenu/nesplnenu - klik na polozku v zozname

vymazat polozku - klik a podrzanie polozky v zozname

vymazat vsetky splnene polozky - tlacidlo hore 'delete all checked'


Notifikacie:

po pridani polozky po deadline/pri nacitani zoznamu ak obsahuje nesplnene polozky po deadline - vibracia, zvukove upozornenie, bliknutie nesplnenych poloziek po deadline 


