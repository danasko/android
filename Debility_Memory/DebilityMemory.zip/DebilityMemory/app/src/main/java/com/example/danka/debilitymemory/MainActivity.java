package com.example.danka.debilitymemory;


import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Vibrator;
import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class MainActivity extends AppCompatActivity {


    private EditText txt;
    private Button btn;
    private ListView list;
    private DatePicker dp;
    private Button dlbtn;
    private Button submit;
    private Button del;
 //   private ArrayList<Boolean> past;
    List<Map<String, String>> data;
    // private ArrayAdapter<String> adapter;
    private SimpleAdapter adapter;
  //  private ArrayList arrayList;
 //   ConstraintLayout.LayoutParams params;
    ConstraintLayout lay;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        submit = (Button) findViewById(R.id.submit);
        btn = (Button)findViewById(R.id.button);
        list = (ListView) findViewById(R.id.list);
        txt = (EditText) findViewById(R.id.editText);
        dp = (DatePicker) findViewById(R.id.datePicker);
        dlbtn = (Button) findViewById(R.id.deadline);
        del = (Button) findViewById(R.id.delete);
     //   arrayList = new ArrayList<>();
       // adapter = new ArrayAdapter(getApplicationContext(), R.layout.list_layout, R.id.list_content , arrayList);

        data = new ArrayList<Map<String, String>>();


        ObjectInput input;
        File file;
        try {
            file = new File(getFilesDir(), "MyFile");

            input = new ObjectInputStream(new FileInputStream(file));
            data = (ArrayList<Map<String,String>>) input.readObject();
            input.close();

        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }


        adapter = new SimpleAdapter(this, data, android.R.layout.simple_list_item_2,
                new String[] {"title", "date", "done"},
                new int[] {android.R.id.text1,
                        android.R.id.text2}) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                // Get the current item from ListView
                View view = super.getView(position, convertView, parent);
                TextView text2 = (TextView) view.findViewById(android.R.id.text2);
                text2.setTextColor(Color.DKGRAY);
                text2.setText("due to " + text2.getText());

                Animation myFadeInAnimation = AnimationUtils.loadAnimation(MainActivity.this, R.anim.tween);

                String[] d = data.get(position).get("date").split("/");
                int day = Integer.valueOf(d[0]);
                int month = Integer.valueOf(d[1]);
                int year = Integer.valueOf(d[2]);
                if(data.get(position).get("done").equals("yes")){
                    view.setBackgroundColor(Color.argb(120, 169, 196, 164));
                }
                else if(isAfterDeadline(year, month, day)==true){
                    view.setBackgroundColor(Color.argb(100, 201, 126, 143));
                    view.startAnimation(myFadeInAnimation);
                }
                if(isAfterDeadline(year, month, day)==false){
                    TextView text1 = (TextView) view.findViewById(android.R.id.text1);
                    text1.setTypeface(null, Typeface.BOLD);
                    text2.setTypeface(null, Typeface.BOLD);
                }

                return view;
            }


        };

        list.setAdapter(adapter);
        lay = (ConstraintLayout)findViewById(R.id.layout);
      //  params = new ConstraintLayout.LayoutParams(ConstraintLayout.LayoutParams.WRAP_CONTENT, ConstraintLayout.LayoutParams.WRAP_CONTENT);


        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Log.d("btn", "pressed");
                if (txt.getText().toString().equals("")) {
                    Toast.makeText(MainActivity.this, "Enter new item first", Toast.LENGTH_SHORT).show();
                } else if(submit.getText().toString().equals("OK")){
                    Toast.makeText(MainActivity.this, "Enter deadline for the item", Toast.LENGTH_SHORT).show();
                }
                else {
                    Toast.makeText(MainActivity.this, "New item added", Toast.LENGTH_SHORT).show();


                    //arrayList.add(txt.getText().toString() + "  " + submit.getText());

                    Map<String, String> item = new HashMap<String, String>(3);
                    item.put("title", txt.getText().toString());
                    String date =submit.getText().toString();
                    item.put("date", date);
                    item.put("done", "no");

                    String[] d = date.split("/");
                    if(isAfterDeadline(Integer.valueOf(d[2]),Integer.valueOf(d[1]),Integer.valueOf(d[0]))==true){
                        notification();
                    }


                    data.add(item);
                    adapter.notifyDataSetChanged();

                    submit.setText("OK");
                    submit.setVisibility(View.INVISIBLE);
                    dlbtn.setVisibility(View.VISIBLE);
                    adapter.notifyDataSetChanged();
                    txt.setText("");
                }
            }
        });


        dlbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dlbtn.setVisibility(View.INVISIBLE);
                dp.setVisibility(View.VISIBLE);
                submit.setVisibility(View.VISIBLE);
            }
        });

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dp.setVisibility(View.INVISIBLE);

                submit.setText(dp.getDayOfMonth() + "/" + (dp.getMonth()+1) + "/" + dp.getYear());
            }
        });


        list.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {

            @Override
            public boolean onItemLongClick(AdapterView<?> arg0, final View arg1, final int position, final long arg3) {

                AlertDialog.Builder adb=new AlertDialog.Builder(MainActivity.this);
                adb.setTitle("Delete?");
                adb.setMessage("Are you sure you want to delete this item?");
                final int positionToRemove = position;
                adb.setNegativeButton("Cancel", null);
                adb.setPositiveButton("Ok", new AlertDialog.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        data.remove(list.getItemAtPosition(position));
                        adapter.notifyDataSetChanged();
                        list.setAdapter(adapter);

                    }});
                adb.show();
                return true;
            }
        });

        list.setOnItemClickListener(new AdapterView.OnItemClickListener(){

            @Override
            public void onItemClick(AdapterView<?> parent, View view, final int position, long id) {
                AlertDialog.Builder adb=new AlertDialog.Builder(MainActivity.this);
                adb.setTitle("Mark as checked?");
                adb.setMessage("Select the state of this item");
                final int positionToRemove = position;
                adb.setNegativeButton("Unchecked", new AlertDialog.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        data.get(position).put("done", "no");
                        adapter.notifyDataSetChanged();
                        list.setAdapter(adapter);
                    }});
                adb.setPositiveButton("Checked", new AlertDialog.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        data.get(position).put("done", "yes");
                        adapter.notifyDataSetChanged();
                        list.setAdapter(adapter);

                    }});
                adb.show();
            }
        });

        del.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder adb=new AlertDialog.Builder(MainActivity.this);
                adb.setTitle("Delete all checked items?");
                adb.setMessage("Are you sure you want to delete all checked items?");
                adb.setNegativeButton("Cancel", null);
                adb.setPositiveButton("Ok", new AlertDialog.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        deleteAllChecked();

                        adapter.notifyDataSetChanged();
                        list.setAdapter(adapter);

                    }});
                adb.show();
            }
        });


        notifs();
    }

    protected void deleteAllChecked() {
        ArrayList erase = new ArrayList();
        for (Map<String, String> item : data) {
            if (item.get("done").equals("yes")) {
                erase.add(item);
            }
        }

        for (Object item : erase) {
            data.remove(item);
        }
    }

    protected void notification(){
        Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        // Vibrate for 500 milliseconds
        v.vibrate(500);
        MediaPlayer sound = MediaPlayer.create(getApplicationContext(), R.raw.served);
        sound.start();
    }


    protected void notifs(){
        boolean vib = false;

        for (Map<String,String> item: data){
            String[] line = item.get("date").split("/");
            int day = Integer.valueOf(line[0]);
            int month = Integer.valueOf(line[1]);
            int year = Integer.valueOf(line[2]);

            if(item.get("done").equals("no") && isAfterDeadline(year,month,day)==true){
                vib = true;
            }
        }

        if(vib==true){
            notification();
        }

    }

    protected boolean isAfterDeadline(int year, int month, int day) {
        String date = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
        String[] d = date.split("-");
     //   Log.e("datum", date + " "+year + " "+month + " "+day);
        if ((year < Integer.valueOf(d[0])) || (year== Integer.valueOf(d[0]) && (month <Integer.valueOf(d[1]))) || (( month==Integer.valueOf(d[1]) && day <= Integer.valueOf(d[2])))) {
          //  Log.e("datum", "som tu");
            return true;
        }

        return false;
    }


    @Override
    protected void onPause(){

        File file;
        ObjectOutputStream outputStream;
        try {
            file = new File(getFilesDir(), "MyFile");

            outputStream = new ObjectOutputStream(new FileOutputStream(file));
            outputStream.writeObject(data);
           // outputStream.writeObject(past);
            outputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        super.onPause();
    }


}




