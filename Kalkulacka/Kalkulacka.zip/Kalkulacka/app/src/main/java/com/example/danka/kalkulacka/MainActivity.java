package com.example.danka.kalkulacka;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {
    private TextView text;
    private Button btn0;
    private Button btn1;
    private Button btn2;
    private Button btn3;
    private Button btn4;
    private Button btn5;
    private Button btn6;
    private Button btnplus;
    private Button btnminus;
    private Button btntimes;
    private Button btneq;
    private Button btnC;
    private String load;
    private int res;
    private String operation;
    private boolean empty;

    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        text = (TextView) findViewById(R.id.text);
        btn0 = (Button) findViewById(R.id.btn0);
        btn1 = (Button) findViewById(R.id.btn1);
        btn2 = (Button) findViewById(R.id.btn2);
        btn3 = (Button) findViewById(R.id.btn3);
        btn4 = (Button) findViewById(R.id.btn4);
        btn5 = (Button) findViewById(R.id.btn5);
        btn6 = (Button) findViewById(R.id.btn6);
        btnplus = (Button) findViewById(R.id.btnplus);
        btnminus = (Button) findViewById(R.id.btnminus);
        btntimes = (Button) findViewById(R.id.btntimes);
        btneq = (Button) findViewById(R.id.btneq);
        btnC = (Button) findViewById(R.id.btnC);
        res = 0;
        operation = "";
        load = "";
        empty = true;

        text.setText("0");
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                numberPressed(1);
            }
        });

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {numberPressed(2);}
        });

        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                numberPressed(3);
            }
        });

        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                numberPressed(4);
            }
        });

        btn5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                numberPressed(5);
            }
        });

        btn6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                numberPressed(6);
            }
        });

        btn0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                numberPressed(0);

            }
        });

        btnC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                text.setText("0");
                operation = "";
                load = "";
                res = 0;
                empty = true;
            }
        });

        btnplus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count();
                operation = "+";
                text.setText(Integer.toString(res, 7));
                empty = true;
            }
        });

        btnminus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count();
                operation = "-";
                text.setText(Integer.toString(res, 7));
                empty = true;
            }
        });

        btntimes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count();
                operation = "*";
                text.setText(Integer.toString(res, 7));
                empty = true;
            }
        });

        btneq.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count();
                operation = "";
                text.setText(Integer.toString(res, 7));
                empty = true;
            }
        });
    }

    protected  void numberPressed(int num){
        if(empty == true){
            text.setText(Integer.toString(num));
            add(num);
            empty = false;
        }else if(!(text.getText().toString().equals("0") && num==0)){
            text.setText(text.getText().toString()+Integer.toString(num));
            add(num);
            empty = false;
        }


    }

    protected void add(int num){
        load += Integer.toString(num);
    }

    protected void count(){
        switch (operation){
            case "": if(text.getText().toString().equals("")){res = 0;}
                    else {res = Integer.parseInt(text.getText().toString(), 7);}  // result in decimal
                break;

            case "+": if(!text.getText().toString().equals("")){
                    res += Integer.parseInt(text.getText().toString(), 7);}  // in decimal
                break;
            case "-": if(!text.getText().toString().equals("")){
                    res -= Integer.parseInt(text.getText().toString(), 7);}
                break;
            case "*": if(text.getText().toString().equals("")){ res = 0;}
                     else{ res *= Integer.parseInt(text.getText().toString(), 7);}
                break;
            default:
                break;
        }
        load = "";


    }


}
